/* =======================================================
 * File: admin-router.js - ĐÃ FIX LỖI KÍCH HOẠT MODULE
 * =======================================================
 */

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function showToast(message, type = 'success') {
    const host = document.getElementById('toastHost');
    if (!host) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? '<i class="bi bi-check-circle-fill"></i>' : '<i class="bi bi-exclamation-triangle-fill"></i>';
    toast.innerHTML = `<div class="msg" style="display:flex; align-items:center; gap:10px; font-weight:700;">${icon} <span>${message}</span></div>`;
    host.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('show'));
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
window.toast = showToast;

async function loadModule(moduleName) {
    const contentArea = document.getElementById('content-area');
    const pageTitle = document.getElementById('pageTitle');

    contentArea.innerHTML = `<div style="text-align:center; padding:50px;"><div style="font-size:20px; font-weight:700;">ĐANG TẢI DỮ LIỆU...</div></div>`;

    let url = '';
    let title = '';

    switch(moduleName) {
        case 'dashboard': url = '/dashboard.html'; title = 'DASHBOARD'; break;
        case 'catalogs': url = '/catalogs'; title = 'QUẢN LÝ THUỘC TÍNH'; break;
        case 'staff': url = '/staff'; title = 'QUẢN LÝ NHÂN VIÊN'; break;
        case 'products': url = '/products.html'; title = 'QUẢN LÝ SẢN PHẨM'; break;
        case 'orders': url = '/orders.html'; title = 'QUẢN LÝ ĐƠN HÀNG'; break;
        case 'users': url = '/users.html'; title = 'QUẢN LÝ TÀI KHOẢN'; break;
        default:
            contentArea.innerHTML = `<div style="padding:40px; text-align:center;">MODULE KHÔNG TỒN TẠI</div>`;
            return;
    }

    if(pageTitle) pageTitle.textContent = title;

    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`Lỗi ${res.status}: Không tìm thấy module`);
        const html = await res.text();

        delete window.initStaff;
        delete window.initCatalogs;

        contentArea.innerHTML = html;

        setTimeout(() => {
            executeScripts(contentArea, moduleName);
        }, 50);

        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.classList.remove('active');
            if(item.getAttribute('href') === '#' + moduleName) item.classList.add('active');
        });

    } catch (err) {
        console.error(err);
        contentArea.innerHTML = `<div style="padding:40px; text-align:center; color:red;"><h3>LỖI TẢI TRANG</h3><p>${err.message}</p></div>`;
    }
}

function executeScripts(container, moduleName) {
    const scripts = container.querySelectorAll('script');

    Array.from(scripts).forEach(oldScript => {
        const newScript = document.createElement('script');
        if (oldScript.src) {
            Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
        } else {
            // Thay vì dùng eval, ta tạo thẻ script mới để trình duyệt tự thực thi chuẩn hơn
            newScript.textContent = oldScript.innerHTML;
        }
        document.body.appendChild(newScript);
        newScript.remove(); // Chạy xong xóa ngay cho sạch
        oldScript.remove();
    });

    // KÍCH HOẠT HÀM INIT
    setTimeout(() => {
        console.log(`🚀 Kích hoạt Init cho: ${moduleName}`);

        if (moduleName === 'catalogs' && typeof window.initCatalogs === 'function') {
            window.initCatalogs();
        }
        else if (moduleName === 'staff' && typeof window.initStaff === 'function') {
            window.initStaff();
            console.log("✅ initStaff đã chạy!");
        }
        else if (moduleName === 'products' && typeof window.initProducts === 'function') {
            window.initProducts();
        }
    }, 100);
}

function initRouter() {
    const hash = window.location.hash.slice(1) || 'dashboard';
    loadModule(hash);
}

window.addEventListener('hashchange', () => {
    const hash = window.location.hash.slice(1);
    loadModule(hash);
});

document.addEventListener('DOMContentLoaded', initRouter);